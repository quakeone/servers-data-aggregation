﻿namespace ServerDataAggregation.Query
{
    public class Class1
    {

    }
}